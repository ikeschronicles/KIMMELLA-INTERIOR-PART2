Part 2 Improvement Document

Area	Part 1	Improvements Made in Part 2
Website Styling	The website had basic HTML styling and structure.	Added an external CSS stylesheet to improve the overall appearance.
Colours	Used basic colours throughout the pages.	Improved the colour scheme using black, white and gold to match the Kimmella Interior theme.
Typography	Text had basic formatting.	Improved font sizes, headings, spacing and text styling using CSS.
Layout	Content was mainly arranged using the basic HTML structure.	Used Flexbox and CSS Grid to create a cleaner and more organised layout.
Navigation	Basic navigation between the pages.	Improved the navigation styling and added hover effects to make it more interactive.
Images	Images were displayed using basic HTML.	Made the images responsive so they adjust better to different screen sizes.
Responsive Design	Mainly designed for desktop screens.	Added media queries and breakpoints for desktop, tablet and mobile devices.
Spacing	Basic spacing between sections and elements.	Improved margins, padding and gaps to make the pages easier to read.
Buttons & Links	Basic links and buttons.	Added hover, focus and active effects to improve user interaction.
